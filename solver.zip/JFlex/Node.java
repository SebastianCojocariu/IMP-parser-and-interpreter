import java.io.BufferedWriter;
import java.util.HashMap;

public class Node {
    public int line = 0;
    static BufferedWriter output_tree;
    static BufferedWriter output_vars;
    int number_tabs = 0;
    public Visitor visitor = new Visitor();
    public static HashMap<String,Integer> hash;

    public String create_tabs(){
        String res = "";
        for(int i=0;i<number_tabs;i++)
            res = res + "\t";
        return res;
    }
}

public class WhileNode extends Node{
    Node condition;
    Node child;

    public WhileNode(){

    }

    public WhileNode(Node condition,Node child){
        this.condition = condition;
        this.child = child;
    }

    public String toString(){
        String res = create_tabs() + "<WhileNode> while\n";
        //String res = create_tabs() + "<WhileNode> while " + line + "\n";
        try {
            output_tree.write(res);
        } catch(Exception e){

        }
        return res;
    }

    public MyObject accept(){
        return visitor.visit(this);
    }
}

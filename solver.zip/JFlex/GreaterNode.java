public class GreaterNode extends Node{
    Node left;
    Node right;

    public GreaterNode(){

    }

    public GreaterNode(Node left,Node right){
        this.left = left;
        this.right = right;
    }

    public String toString(){
        String res = create_tabs() + "<GreaterNode> >\n";
        //String res = create_tabs() + "<GreaterNode> > " + line + "\n";
        try {
            output_tree.write(res);
        } catch(Exception e){

        }
        return res;
    }

    public MyObject accept(){
        return visitor.visit(this);
    }
}

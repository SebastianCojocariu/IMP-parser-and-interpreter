import java.util.ArrayList;

public class MainNode extends Node {
    public Node statement;

    public MainNode(){
        statement = new StatementNode();
    }
    public MainNode(Node statement){
        this.statement = statement ;
    }

    public String toString(){
        String res = create_tabs() + "<MainNode>\n";
        //String res = create_tabs() + "<MainNode> " + line + "\n";
        try {
            output_tree.write(res);
        } catch(Exception e){

        }
        return res;
    }

    public MyObject accept(){
        return visitor.visit(this);
    }



}

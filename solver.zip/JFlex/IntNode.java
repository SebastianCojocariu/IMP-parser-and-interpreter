public class IntNode extends Node {
    int value;
    public IntNode(){

    }

    public IntNode(int value){
        this.value = value;
    }

    public String toString() {
        String res = create_tabs() + "<IntNode> " + value+ "\n";
       // String res = create_tabs() + "<IntNode> " + value + " " + line + "\n";
        try {
            output_tree.write(res);
        } catch(Exception e){

        }
        return res;
    }

    public MyObject accept(){

        return visitor.visit(this);
    }
}

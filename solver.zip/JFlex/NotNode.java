public class NotNode extends Node{
    Node child;

    public NotNode(){

    }

    public NotNode(Node child){
        this.child = child;
    }

    public String toString(){
        String res = create_tabs() + "<NotNode> !\n";
       // String res = create_tabs() + "<NotNode> ! " + line + "\n";
        try {
            output_tree.write(res);
        } catch(Exception e){

        }
        return res;
    }

    public MyObject accept(){
        return visitor.visit(this);
    }
}

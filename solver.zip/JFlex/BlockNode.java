import java.util.ArrayList;

public class BlockNode extends Node {
    public Node statement = null;

    public BlockNode(){

    }

    public BlockNode(Node statement){
        this.statement = statement;
    }

    public String toString(){
        String res = create_tabs() + "<BlockNode> {}\n";
        //String res = create_tabs() + "<BlockNode> {} " + line + "\n";
        try {
            output_tree.write(res);
        } catch(Exception e){

        }
        return res;
    }

    public MyObject accept(){
        return visitor.visit(this);
    }
}

public class MyObject {
    Integer value_int;
    Boolean value_bool;
    String variable;
    public Integer line;

    public MyObject(){

    }
    public MyObject(Integer line , Integer value_int){
        this.line = line;
        this.value_int = value_int;
    }

    public MyObject(Integer line){
        this.line = line;
    }

    public MyObject(Integer line,Boolean value_bool){

        this.line = line;
        this.value_bool = value_bool;
    }

    public MyObject(Integer line,String variable){
        this.line = line;
        this.variable = variable;
    }

    public MyObject(Integer line,Integer value_int,Boolean value_bool,String variable){
        this.line = line;
        this.value_int = value_int;
        this.value_bool = value_bool;
        this.variable = variable;
    }
}

public class DivNode extends Node {
    Node left;
    Node right;

    public DivNode(){

    }

    public DivNode(Node left,Node right){
        this.left = left;
        this.right = right;
    }

    public String toString() {
        String res = create_tabs() + "<DivNode> /\n";
        //String res = create_tabs() + "<DivNode> / " + line + "\n";
        try {
            output_tree.write(res);
        } catch(Exception e){

        }
        return res;
    }

    public MyObject accept(){
        return visitor.visit(this);
    }

}

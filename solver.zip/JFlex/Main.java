import com.sun.org.apache.xpath.internal.operations.Div;

import java.io.*;
import java.util.*;

public class Main {

    public static ArrayList<String> stack;


    public static void show(Node tree){
        System .out.println(tree);

        if(tree instanceof BracketNode) {
            show(((BracketNode) tree).child);
        }
        else if(tree instanceof NotNode)
            show(((NotNode) tree).child);

        else if(tree instanceof GreaterNode) {
            show(((GreaterNode) tree).left);
            show(((GreaterNode) tree).right);
        }
        else if(tree instanceof AndNode) {
            show(((AndNode) tree).left);
            show(((AndNode) tree).right);
        }
        else if(tree instanceof PlusNode) {
            show(((PlusNode) tree).left);
            show(((PlusNode) tree).right);
        }

        else if(tree instanceof DivNode) {
            show(((DivNode) tree).left);
            show(((DivNode) tree).right);
        }

        else if(tree instanceof AssignmentNode){
            show(((AssignmentNode) tree).variable);
            show(((AssignmentNode) tree).value);
        }

        else if(tree instanceof IfNode){
            show(((IfNode) tree).condition);
            show(((IfNode) tree).left);
            show(((IfNode) tree).right);
        }
        else if(tree instanceof  WhileNode){
            show(((WhileNode) tree).condition);
            show(((WhileNode) tree).child);
        }
        else if(tree instanceof BlockNode){
                if(((BlockNode) tree).statement != null)
                    show(((BlockNode) tree).statement);
        }

        else if(tree instanceof MainNode){
                show(((MainNode) tree).statement);
        }

        else if(tree instanceof StatementNode) {
            if(((StatementNode) tree).left != null)
                show(((StatementNode) tree).left);
            if(((StatementNode) tree).right != null)
                show(((StatementNode) tree).right);
        }

    }

    public static void generate_tabs(Node node,int count){
        if(node == null)
            return;
        node.number_tabs = count;

        if(node instanceof VarNode){
            return;
        }
        if(node instanceof IntNode)
            return;
        if(node instanceof BoolNode)
            return;

        if(node instanceof PlusNode){
            generate_tabs(((PlusNode) node).right,count+1);
            generate_tabs(((PlusNode) node).left,count+1);
        }
        if(node instanceof DivNode){
            generate_tabs(((DivNode) node).right,count+1);
            generate_tabs(((DivNode) node).left,count+1);
        }

        if(node instanceof IfNode){
            generate_tabs(((IfNode) node).condition,count+1);
            generate_tabs(((IfNode) node).left,count+1);
            generate_tabs(((IfNode) node).right,count+1);
        }

        if(node instanceof  WhileNode){
            generate_tabs(((WhileNode) node).condition,count+1);
            generate_tabs(((WhileNode) node).child,count+1);
        }

        if(node instanceof  BracketNode){
            generate_tabs(((BracketNode) node).child,count+1);
        }

        if(node instanceof  BlockNode){
            generate_tabs(((BlockNode) node).statement,count+1);
        }
        if(node instanceof GreaterNode){
            generate_tabs(((GreaterNode) node).left,count+1);
            generate_tabs(((GreaterNode) node).right,count+1);
        }
        if(node instanceof AndNode){
            generate_tabs(((AndNode) node).left,count+1);
            generate_tabs(((AndNode) node).right,count+1);
        }
        if(node instanceof NotNode){
            generate_tabs(((NotNode) node).child,count+1);
        }
        if(node instanceof  MainNode){
                generate_tabs(((MainNode) node).statement,count+1);
        }
        if(node instanceof AssignmentNode){
            generate_tabs(((AssignmentNode) node).variable,count+1);
            generate_tabs(((AssignmentNode) node).value,count+1);
        }
        if(node instanceof StatementNode) {
            generate_tabs(((StatementNode) node).left, count + 1);
            generate_tabs(((StatementNode) node).right,count + 1);
        }

    }

    static public Node getStatements(Stack<Node> stack){
        ArrayList<Node> listChildren = new ArrayList<>();
        while(!stack.isEmpty()) {
            listChildren.add(0,stack.pop());
        }
        if(listChildren.size() == 0)
            return new StatementNode();
        else if(listChildren.size() == 1) {
            return listChildren.get(0);
        }
        else{
            Node res = null;
            Node statementNode = new StatementNode();
            ((StatementNode) statementNode).right = listChildren.get(listChildren.size()-1);
            ((StatementNode) statementNode).left = listChildren.get(listChildren.size()-2);
            res = statementNode;
            for(int i= listChildren.size()-3;i>=0;i--){
                res = new StatementNode();
                ((StatementNode) res).right = statementNode;
                ((StatementNode) res).left = listChildren.get(i);
                statementNode = res;

            }
            return res;
        }

    }

    static public void getUnassignedVar(Node tree,BufferedWriter out_vars){
        if(tree instanceof VarNode) {
            if (!Node.hash.containsKey(((VarNode) tree).variable)) {
                try {
                    out_vars.write("UnassignedVar " + tree.line + "\n");
                    out_vars.close();

                } catch (Exception e) {

                }
                System.exit(-1);
            }
        }


        else if(tree instanceof IntNode)
            return;

        else if(tree instanceof BoolNode)
            return;

        else if(tree instanceof BracketNode) {
            getUnassignedVar(((BracketNode) tree).child,out_vars);
        }
        else if(tree instanceof NotNode)
            getUnassignedVar(((NotNode) tree).child,out_vars);

        else if(tree instanceof GreaterNode) {
            getUnassignedVar(((GreaterNode) tree).left,out_vars);
            getUnassignedVar(((GreaterNode) tree).right,out_vars);
        }
        else if(tree instanceof AndNode) {
            getUnassignedVar(((AndNode) tree).left,out_vars);
            getUnassignedVar(((AndNode) tree).right,out_vars);
        }
        else if(tree instanceof PlusNode) {
            getUnassignedVar(((PlusNode) tree).left,out_vars);
            getUnassignedVar(((PlusNode) tree).right,out_vars);
        }

        else if(tree instanceof DivNode) {
            getUnassignedVar(((DivNode) tree).left,out_vars);
            getUnassignedVar(((DivNode) tree).right,out_vars);
        }

        else if(tree instanceof AssignmentNode){
            getUnassignedVar(((AssignmentNode) tree).variable,out_vars);
            getUnassignedVar(((AssignmentNode) tree).value,out_vars);
        }

        else if(tree instanceof IfNode){
            getUnassignedVar(((IfNode) tree).condition,out_vars);
            getUnassignedVar(((IfNode) tree).left,out_vars);
            getUnassignedVar(((IfNode) tree).right,out_vars);
        }
        else if(tree instanceof  WhileNode){
            getUnassignedVar(((WhileNode) tree).condition,out_vars);
            getUnassignedVar(((WhileNode) tree).child,out_vars);
        }
        else if(tree instanceof BlockNode){
            if(((BlockNode) tree).statement != null)
                getUnassignedVar(((BlockNode) tree).statement,out_vars);
        }

        else if(tree instanceof MainNode){
            getUnassignedVar(((MainNode) tree).statement,out_vars);
        }

        else if(tree instanceof StatementNode) {
            if(((StatementNode) tree).left != null)
                getUnassignedVar(((StatementNode) tree).left,out_vars);
            if(((StatementNode) tree).right != null)
                getUnassignedVar(((StatementNode) tree).right,out_vars);
        }

    }



    public static void main(String[] args) throws IOException {


      // BufferedWriter output_tree= new BufferedWriter(new FileWriter(new File("/Users/sebastiancojocariu/Desktop/teme/lfa/checker_lfa_2018/test/out/" + args[0].substring(0,args[0].length()-2) +"tree.out") ));
      // BufferedWriter output_vars= new BufferedWriter(new FileWriter(new File("/Users/sebastiancojocariu/Desktop/teme/lfa/checker_lfa_2018/test/out/" + args[0].substring(0,args[0].length()-2) +"vars.out") ));
        BufferedWriter output_tree = new BufferedWriter(new FileWriter(new File("arbore")));
        BufferedWriter output_vars = new BufferedWriter(new FileWriter(new File("output")));
        Node.output_tree = output_tree;
        Node.output_vars = output_vars;
        //HelloLexer lexer = new HelloLexer(new FileReader("/Users/sebastiancojocariu/Desktop/teme/lfa/tema/src/input.txt"));

        //HelloLexer lexer = new HelloLexer(new FileReader("/Users/sebastiancojocariu/Desktop/teme/lfa/checker_lfa_2018/test/in/" + args[0]));
       HelloLexer lexer = new HelloLexer(new FileReader("input"));

        lexer.yylex();
        Visitor.out_vars = output_vars;

       // System.out.println(lexer.stack);
        ArrayList<Node> listChildren = new ArrayList<>();


        MainNode mainNode = new MainNode(getStatements(lexer.stack));
        Node.hash = lexer.hash;

        System.out.println(Node.hash);
        generate_tabs(mainNode,0);
        show(mainNode);
        output_tree.close();

        //interpreter
        getUnassignedVar(mainNode,output_vars);

         mainNode.accept();
         System.out.println(Node.hash);
         Iterator itr = Node.hash.entrySet().iterator();
         while(itr.hasNext()){
             Map.Entry pair = (Map.Entry)itr.next();
             output_vars.write(pair.getKey() + "=" + pair.getValue()+"\n");
             System.out.println(pair.getKey() + " = " + pair.getValue());
         }


         output_vars.close();

    }
}

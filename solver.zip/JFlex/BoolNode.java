public class BoolNode extends Node {
    String value;

    public BoolNode(){

    }

    public BoolNode(String value){
        this.value = value;
    }

    public String toString(){
        String res = create_tabs() + "<BoolNode> " + value + "\n";
        //String res = create_tabs() + "<BoolNode>  " + value + " " + line + "\n";
        try {
            output_tree.write(res);
        } catch(Exception e){

        }
        return res;
    }

    public MyObject accept(){
        return visitor.visit(this);
    }

}

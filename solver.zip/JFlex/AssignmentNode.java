public class AssignmentNode extends Node{
    Node variable;
    Node value;

    public AssignmentNode(){

    }

    public AssignmentNode(Node variable,Node value){
        this.variable = variable;
        this.value = value;
    }

    public String toString(){
        String res = create_tabs() + "<AssignmentNode> =\n";
        //String res = create_tabs() + "<AssignmentNode> = " + line + "\n";
        try {
            output_tree.write(res);
        } catch(Exception e){

        }
        return res;
    }

    public MyObject accept(){
        return visitor.visit(this);
    }

}

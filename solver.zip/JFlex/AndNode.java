public class AndNode extends Node {
    Node left;
    Node right;


    public AndNode(){

    }

    public AndNode(Node left,Node right){
        this.left = left;
        this.right = right;
    }

    public String toString(){
        String res = create_tabs() + "<AndNode> &&\n";
        //String res = create_tabs() + "<AndNode> && " + line + "\n" ;
        try {
            output_tree.write(res);
        } catch(Exception e){

        }
        return res;
    }

    public MyObject accept(){
        return visitor.visit(this);
    }

}

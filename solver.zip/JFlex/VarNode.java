public class VarNode extends Node{
    String variable;

    public VarNode(){
    }

    public VarNode(String variable){
        this.variable = variable;
    }

    @Override
    public String toString() {
        String res = create_tabs() + "<VariableNode> "+ variable + "\n";
      //  String res = create_tabs() + "<VariableNode> "+variable + " " + line + "\n";
        try {
            output_tree.write(res);
        } catch(Exception e){

        }
        return res;
    }

    public MyObject accept(){
        return visitor.visit(this);
    }
}

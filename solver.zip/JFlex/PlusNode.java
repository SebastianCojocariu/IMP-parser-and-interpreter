public class PlusNode extends Node{
    Node left;
    Node right;

    public PlusNode(){

    }

    public PlusNode(Node left,Node right){
        this.left = left;
        this.right = right;
    }

    public String toString() {
        String res = create_tabs() + "<PlusNode> +\n";
        //String res = create_tabs() + "<PlusNode> + " + line + "\n";
        try {
            output_tree.write(res);
        } catch(Exception e){

        }
        return res;
    }

    public MyObject accept(){
        return visitor.visit(this);
    }
}

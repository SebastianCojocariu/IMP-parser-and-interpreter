public class BracketNode extends Node{
    Node child;

    public BracketNode(){

    }

    public BracketNode(Node child){
        this.child = child;
    }

    public String toString(){
        String res = create_tabs() + "<BracketNode> ()\n";
        //String res = create_tabs() + "<BracketNode> () " + line + "\n";
        try {
            output_tree.write(res);
        } catch(Exception e){

        }
        return res;
    }

    public MyObject accept(){
        return visitor.visit(this);
    }

}

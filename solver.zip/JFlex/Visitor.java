

import java.io.BufferedWriter;

public class Visitor {
    public static boolean unassigned_variable = false;
    public static boolean divide_zero = false;
    public static BufferedWriter out_vars;


    public MyObject visit(Node node){

        System.out.println(node);
        System.out.println(Node.hash);

        if(node instanceof MainNode) {
            visit(((MainNode) node).statement);
            return new MyObject(node.line);
        }
        else if(node instanceof AndNode){
            MyObject obj1 = visit(((AndNode) node).left);
            if(obj1.value_bool == false)
                return new MyObject(node.line,false);
            MyObject obj2 = visit(((AndNode) node).right);
            return new MyObject(node.line,obj1.value_bool && obj2.value_bool);

        }

        else if(node instanceof NotNode){
            MyObject obj = visit(((NotNode) node).child);
            return new MyObject(node.line,!obj.value_bool);

        }
        else if(node instanceof GreaterNode){
            int x = -1,y = -1;
            MyObject obj1 = visit(((GreaterNode) node).left);
            MyObject obj2 = visit(((GreaterNode) node).right);

            if(obj1.variable != null){
                if(Node.hash.containsKey(obj1.variable) && Node.hash.get(obj1.variable) != null)
                    x = Node.hash.get(obj1.variable);
                else {
                    try {
                        out_vars.write("UnassignedVar "+ obj1.line +"\n");
                        out_vars.close();
                    }catch(Exception e){
                    }
                    System.exit(-1);
                }
            }
            else
                x = obj1.value_int;

            if(obj2.variable != null){
                if(Node.hash.containsKey(obj2.variable) && Node.hash.get(obj2.variable) != null)
                    y = Node.hash.get(obj2.variable);
                else {
                    try {
                        out_vars.write("UnassignedVar "+ obj2.line +"\n");
                        out_vars.close();
                    }catch(Exception e){
                    }
                    System.exit(-1);
                }
            }
            else
                y = obj2.value_int;

            return new MyObject(node.line,x > y);
        }
//----------------Plus and Div


        else if(node instanceof DivNode){
            int x = -1,y = -1;
            MyObject obj1= visit(((DivNode) node).left);
            MyObject obj2= visit(((DivNode) node).right);

            if(obj1.variable != null){
                if(Node.hash.containsKey(obj1.variable) && Node.hash.get(obj1.variable) != null)
                    x = Node.hash.get(obj1.variable);
                else {
                    try {
                        out_vars.write("UnassignedVar "+ obj1.line +"\n");
                        out_vars.close();
                    } catch (Exception e) {
                    }
                    System.exit(-1);
                }
            }
            else
                x = obj1.value_int;

            if(obj2.variable != null){
                if(Node.hash.containsKey(obj2.variable) && Node.hash.get(obj2.variable) != null)
                    y = Node.hash.get(obj2.variable);
                else {
                    try {
                        out_vars.write("UnassignedVar "+ obj2.line +"\n");
                        out_vars.close();
                    }catch(Exception e){

                    }
                    System.exit(-1);
                }
            }
            else
                y = obj2.value_int;

            if(y == 0) {
                try {
                    out_vars.write("DivideByZero "+obj2.line+"\n");
                    out_vars.close();
                }catch(Exception e){
                }
                System.exit(-1);
            }

            return new MyObject(node.line,x / y);
        }

        else if(node instanceof PlusNode){
            int x = -1,y = -1;
            MyObject obj1 = visit(((PlusNode) node).left);
            MyObject obj2 = visit(((PlusNode) node).right);

            if(obj1.variable != null){
                if(Node.hash.containsKey(obj1.variable) && Node.hash.get(obj1.variable) != null)
                    x = Node.hash.get(obj1.variable);
                else {
                    try {
                        out_vars.write("UnassignedVar "+ obj1.line +"\n");
                        out_vars.close();
                    } catch (Exception e) {
                    }
                    System.exit(-1);
                }
            }
            else
                x = obj1.value_int;

            if(obj2.variable != null){
                if(Node.hash.containsKey(obj2.variable) && Node.hash.get(obj2.variable) != null)
                    y = Node.hash.get(obj2.variable);
                else {
                    try {
                        out_vars.write("UnassignedVar "+ obj2.line +"\n");
                        out_vars.close();
                    }catch(Exception e){
                    }
                    System.exit(-1);
                }
            }
            else
                y = obj2.value_int;

            return new MyObject(node.line,x + y);
        }


//---------------Assignment---------------
        else if(node instanceof AssignmentNode){
            //System.out.println("AssignmentNode");
            MyObject obj1 = visit(((AssignmentNode) node).variable);
            MyObject obj2 = visit(((AssignmentNode) node).value);
            String variable = null;
            int value = -1;

            if(obj1.variable == null||!Node.hash.containsKey(obj1.variable)){
                    try {
                        out_vars.write("UnassignedVar "+ obj1.line +"\n");
                        out_vars.close();
                    } catch (Exception e) { }
                    System.exit(-1);
            }
            else
                variable = obj1.variable;

            if(obj2.variable != null){
                if(!Node.hash.containsKey(obj2.variable) || Node.hash.get(obj2.variable) == null){
                    try {
                        out_vars.write("UnassignedVar "+ obj2.line +"\n");
                        out_vars.close();
                    } catch (Exception e) { }
                    System.exit(-1);
                }
                else {
                    value = Node.hash.get(obj2.variable);

                }
            }
            else
                value = obj2.value_int;

            Node.hash.put(variable,value);

            return new MyObject(node.line);

        }
//---------- Variable + BoolNode + IntNode----------
        else if(node instanceof BoolNode){
            if(((BoolNode) node).value == null)
                return new MyObject();
            else if(((BoolNode) node).value.equals("true"))
                return new MyObject(node.line,true);
            else
                return new MyObject(node.line,false);
        }

        else if(node instanceof IntNode){
            return new MyObject(node.line,((IntNode) node).value);
        }

        else if(node instanceof VarNode){
           // System.out.println(((VarNode) node).variable);
            //if(Node.hash.containsKey(((VarNode) node).variable))
                return new MyObject(node.line,((VarNode) node).variable);
          //  else return new MyObject();
        }


//--------------Conditions---------------
        else if(node instanceof IfNode){
            MyObject obj_condition = visit(((IfNode) node).condition);
            if(obj_condition.value_bool)
                visit(((IfNode) node).left);
            else
                visit(((IfNode) node).right);
            return new MyObject(node.line);

        }

        else if(node instanceof WhileNode) {
            MyObject obj_condition;
            while ((obj_condition = visit(((WhileNode) node).condition)).value_bool) {
                visit(((WhileNode) node).child);
            }
            return new MyObject(node.line);
        }


        //--------------  Blocks -----------------

        else if(node instanceof BlockNode){
                if(((BlockNode) node).statement == null)
                    return new MyObject(node.line);

                visit(((BlockNode) node).statement);
                return new MyObject(node.line);
        }

        else if(node instanceof BracketNode){
            return visit(((BracketNode) node).child);
        }

        else if(node instanceof StatementNode){
            if(node == null)
                return new MyObject();
            if(((StatementNode) node).left != null)
                 visit(((StatementNode) node).left);
            if(((StatementNode) node).right != null)
                 visit(((StatementNode) node).right);

            return new MyObject(node.line);

        }

        else{

                return new MyObject(node.line);
        }


    }


}

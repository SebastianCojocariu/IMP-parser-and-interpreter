public class StatementNode extends Node {
    public Node left;
    public Node right;

    public StatementNode(){

    }
    public String toString(){
        String res = create_tabs() + "<SequenceNode>\n";
       // String res = create_tabs() + "<SequenceNode> " + line + "\n";
        try {
            output_tree.write(res);
        } catch(Exception e){

        }
        return res;
    }

    public MyObject accept(){
        return visitor.visit(this);
    }
}

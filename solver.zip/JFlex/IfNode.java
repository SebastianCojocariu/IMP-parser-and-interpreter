public class IfNode extends Node {
    Node condition;
    Node left;
    Node right;

    public IfNode(){

    }

    public IfNode(Node condition,Node left,Node right){
        this.condition = condition;
        this.left = left;
        this.right = right;
    }

    public String toString(){
        String res = create_tabs() + "<IfNode> if\n";
        //String res = create_tabs() + "<IfNode> if " + line + "\n";
        try {
            output_tree.write(res);
        } catch(Exception e){

        }
        return res;
    }

    public MyObject accept(){
        return visitor.visit(this);
    }
}

// Generated from Hello.g4 by ANTLR 4.7.1
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class HelloParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.7.1", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, WS=9, 
		NUMBER=10, BOOLVAL=11, VAR=12, PLUS=13, DIV=14, AND=15, NOT=16, GREATER=17, 
		EQUAL=18, COMA=19, CP=20;
	public static final int
		RULE_mainNode = 0, RULE_assignment = 1, RULE_initialize = 2, RULE_ifNode = 3, 
		RULE_whileNode = 4, RULE_aexpr = 5, RULE_bexpr = 6, RULE_blockNode = 7, 
		RULE_sequenceNode = 8;
	public static final String[] ruleNames = {
		"mainNode", "assignment", "initialize", "ifNode", "whileNode", "aexpr", 
		"bexpr", "blockNode", "sequenceNode"
	};

	private static final String[] _LITERAL_NAMES = {
		null, "'int'", "'if'", "'{'", "'}'", "'else'", "'while'", "'('", "')'", 
		null, null, null, null, "'+'", "'/'", "'&&'", "'!'", "'>'", "'='", "','", 
		"';'"
	};
	private static final String[] _SYMBOLIC_NAMES = {
		null, null, null, null, null, null, null, null, null, "WS", "NUMBER", 
		"BOOLVAL", "VAR", "PLUS", "DIV", "AND", "NOT", "GREATER", "EQUAL", "COMA", 
		"CP"
	};
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Hello.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public HelloParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class MainNodeContext extends ParserRuleContext {
		public InitializeContext initialize() {
			return getRuleContext(InitializeContext.class,0);
		}
		public SequenceNodeContext sequenceNode() {
			return getRuleContext(SequenceNodeContext.class,0);
		}
		public MainNodeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_mainNode; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HelloListener ) ((HelloListener)listener).enterMainNode(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HelloListener ) ((HelloListener)listener).exitMainNode(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HelloVisitor ) return ((HelloVisitor<? extends T>)visitor).visitMainNode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final MainNodeContext mainNode() throws RecognitionException {
		MainNodeContext _localctx = new MainNodeContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_mainNode);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(18);
			initialize();
			setState(19);
			sequenceNode();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AssignmentContext extends ParserRuleContext {
		public TerminalNode VAR() { return getToken(HelloParser.VAR, 0); }
		public TerminalNode EQUAL() { return getToken(HelloParser.EQUAL, 0); }
		public AexprContext aexpr() {
			return getRuleContext(AexprContext.class,0);
		}
		public TerminalNode CP() { return getToken(HelloParser.CP, 0); }
		public AssignmentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_assignment; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HelloListener ) ((HelloListener)listener).enterAssignment(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HelloListener ) ((HelloListener)listener).exitAssignment(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HelloVisitor ) return ((HelloVisitor<? extends T>)visitor).visitAssignment(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AssignmentContext assignment() throws RecognitionException {
		AssignmentContext _localctx = new AssignmentContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_assignment);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(21);
			match(VAR);
			setState(22);
			match(EQUAL);
			setState(23);
			aexpr(0);
			setState(24);
			match(CP);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class InitializeContext extends ParserRuleContext {
		public List<TerminalNode> VAR() { return getTokens(HelloParser.VAR); }
		public TerminalNode VAR(int i) {
			return getToken(HelloParser.VAR, i);
		}
		public TerminalNode CP() { return getToken(HelloParser.CP, 0); }
		public List<TerminalNode> COMA() { return getTokens(HelloParser.COMA); }
		public TerminalNode COMA(int i) {
			return getToken(HelloParser.COMA, i);
		}
		public InitializeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_initialize; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HelloListener ) ((HelloListener)listener).enterInitialize(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HelloListener ) ((HelloListener)listener).exitInitialize(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HelloVisitor ) return ((HelloVisitor<? extends T>)visitor).visitInitialize(this);
			else return visitor.visitChildren(this);
		}
	}

	public final InitializeContext initialize() throws RecognitionException {
		InitializeContext _localctx = new InitializeContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_initialize);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(26);
			match(T__0);
			setState(27);
			match(VAR);
			setState(32);
			_errHandler.sync(this);
			_la = _input.LA(1);
			while (_la==COMA) {
				{
				{
				setState(28);
				match(COMA);
				setState(29);
				match(VAR);
				}
				}
				setState(34);
				_errHandler.sync(this);
				_la = _input.LA(1);
			}
			setState(35);
			match(CP);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class IfNodeContext extends ParserRuleContext {
		public BexprContext bexpr() {
			return getRuleContext(BexprContext.class,0);
		}
		public List<BlockNodeContext> blockNode() {
			return getRuleContexts(BlockNodeContext.class);
		}
		public BlockNodeContext blockNode(int i) {
			return getRuleContext(BlockNodeContext.class,i);
		}
		public IfNodeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_ifNode; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HelloListener ) ((HelloListener)listener).enterIfNode(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HelloListener ) ((HelloListener)listener).exitIfNode(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HelloVisitor ) return ((HelloVisitor<? extends T>)visitor).visitIfNode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final IfNodeContext ifNode() throws RecognitionException {
		IfNodeContext _localctx = new IfNodeContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_ifNode);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(37);
			match(T__1);
			setState(38);
			bexpr(0);
			setState(39);
			match(T__2);
			setState(40);
			blockNode();
			setState(41);
			match(T__3);
			setState(42);
			match(T__4);
			setState(43);
			match(T__2);
			setState(44);
			blockNode();
			setState(45);
			match(T__3);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class WhileNodeContext extends ParserRuleContext {
		public BexprContext bexpr() {
			return getRuleContext(BexprContext.class,0);
		}
		public BlockNodeContext blockNode() {
			return getRuleContext(BlockNodeContext.class,0);
		}
		public WhileNodeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_whileNode; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HelloListener ) ((HelloListener)listener).enterWhileNode(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HelloListener ) ((HelloListener)listener).exitWhileNode(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HelloVisitor ) return ((HelloVisitor<? extends T>)visitor).visitWhileNode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final WhileNodeContext whileNode() throws RecognitionException {
		WhileNodeContext _localctx = new WhileNodeContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_whileNode);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(47);
			match(T__5);
			setState(48);
			bexpr(0);
			setState(49);
			match(T__2);
			setState(50);
			blockNode();
			setState(51);
			match(T__3);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class AexprContext extends ParserRuleContext {
		public TerminalNode VAR() { return getToken(HelloParser.VAR, 0); }
		public TerminalNode NUMBER() { return getToken(HelloParser.NUMBER, 0); }
		public List<AexprContext> aexpr() {
			return getRuleContexts(AexprContext.class);
		}
		public AexprContext aexpr(int i) {
			return getRuleContext(AexprContext.class,i);
		}
		public TerminalNode DIV() { return getToken(HelloParser.DIV, 0); }
		public TerminalNode PLUS() { return getToken(HelloParser.PLUS, 0); }
		public AexprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_aexpr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HelloListener ) ((HelloListener)listener).enterAexpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HelloListener ) ((HelloListener)listener).exitAexpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HelloVisitor ) return ((HelloVisitor<? extends T>)visitor).visitAexpr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final AexprContext aexpr() throws RecognitionException {
		return aexpr(0);
	}

	private AexprContext aexpr(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		AexprContext _localctx = new AexprContext(_ctx, _parentState);
		AexprContext _prevctx = _localctx;
		int _startState = 10;
		enterRecursionRule(_localctx, 10, RULE_aexpr, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(60);
			_errHandler.sync(this);
			switch (_input.LA(1)) {
			case VAR:
				{
				setState(54);
				match(VAR);
				}
				break;
			case NUMBER:
				{
				setState(55);
				match(NUMBER);
				}
				break;
			case T__6:
				{
				setState(56);
				match(T__6);
				setState(57);
				aexpr(0);
				setState(58);
				match(T__7);
				}
				break;
			default:
				throw new NoViableAltException(this);
			}
			_ctx.stop = _input.LT(-1);
			setState(70);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,3,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					setState(68);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,2,_ctx) ) {
					case 1:
						{
						_localctx = new AexprContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_aexpr);
						setState(62);
						if (!(precpred(_ctx, 3))) throw new FailedPredicateException(this, "precpred(_ctx, 3)");
						setState(63);
						match(DIV);
						setState(64);
						aexpr(3);
						}
						break;
					case 2:
						{
						_localctx = new AexprContext(_parentctx, _parentState);
						pushNewRecursionContext(_localctx, _startState, RULE_aexpr);
						setState(65);
						if (!(precpred(_ctx, 2))) throw new FailedPredicateException(this, "precpred(_ctx, 2)");
						setState(66);
						match(PLUS);
						setState(67);
						aexpr(3);
						}
						break;
					}
					} 
				}
				setState(72);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,3,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class BexprContext extends ParserRuleContext {
		public TerminalNode VAR() { return getToken(HelloParser.VAR, 0); }
		public TerminalNode BOOLVAL() { return getToken(HelloParser.BOOLVAL, 0); }
		public TerminalNode NOT() { return getToken(HelloParser.NOT, 0); }
		public List<BexprContext> bexpr() {
			return getRuleContexts(BexprContext.class);
		}
		public BexprContext bexpr(int i) {
			return getRuleContext(BexprContext.class,i);
		}
		public List<AexprContext> aexpr() {
			return getRuleContexts(AexprContext.class);
		}
		public AexprContext aexpr(int i) {
			return getRuleContext(AexprContext.class,i);
		}
		public TerminalNode GREATER() { return getToken(HelloParser.GREATER, 0); }
		public TerminalNode AND() { return getToken(HelloParser.AND, 0); }
		public BexprContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_bexpr; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HelloListener ) ((HelloListener)listener).enterBexpr(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HelloListener ) ((HelloListener)listener).exitBexpr(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HelloVisitor ) return ((HelloVisitor<? extends T>)visitor).visitBexpr(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BexprContext bexpr() throws RecognitionException {
		return bexpr(0);
	}

	private BexprContext bexpr(int _p) throws RecognitionException {
		ParserRuleContext _parentctx = _ctx;
		int _parentState = getState();
		BexprContext _localctx = new BexprContext(_ctx, _parentState);
		BexprContext _prevctx = _localctx;
		int _startState = 12;
		enterRecursionRule(_localctx, 12, RULE_bexpr, _p);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(86);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,4,_ctx) ) {
			case 1:
				{
				setState(74);
				match(VAR);
				}
				break;
			case 2:
				{
				setState(75);
				match(BOOLVAL);
				}
				break;
			case 3:
				{
				setState(76);
				match(NOT);
				setState(77);
				bexpr(4);
				}
				break;
			case 4:
				{
				setState(78);
				aexpr(0);
				setState(79);
				match(GREATER);
				setState(80);
				aexpr(0);
				}
				break;
			case 5:
				{
				setState(82);
				match(T__6);
				setState(83);
				bexpr(0);
				setState(84);
				match(T__7);
				}
				break;
			}
			_ctx.stop = _input.LT(-1);
			setState(93);
			_errHandler.sync(this);
			_alt = getInterpreter().adaptivePredict(_input,5,_ctx);
			while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER ) {
				if ( _alt==1 ) {
					if ( _parseListeners!=null ) triggerExitRuleEvent();
					_prevctx = _localctx;
					{
					{
					_localctx = new BexprContext(_parentctx, _parentState);
					pushNewRecursionContext(_localctx, _startState, RULE_bexpr);
					setState(88);
					if (!(precpred(_ctx, 3))) throw new FailedPredicateException(this, "precpred(_ctx, 3)");
					setState(89);
					match(AND);
					setState(90);
					bexpr(4);
					}
					} 
				}
				setState(95);
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,5,_ctx);
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			unrollRecursionContexts(_parentctx);
		}
		return _localctx;
	}

	public static class BlockNodeContext extends ParserRuleContext {
		public AssignmentContext assignment() {
			return getRuleContext(AssignmentContext.class,0);
		}
		public WhileNodeContext whileNode() {
			return getRuleContext(WhileNodeContext.class,0);
		}
		public IfNodeContext ifNode() {
			return getRuleContext(IfNodeContext.class,0);
		}
		public SequenceNodeContext sequenceNode() {
			return getRuleContext(SequenceNodeContext.class,0);
		}
		public BlockNodeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_blockNode; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HelloListener ) ((HelloListener)listener).enterBlockNode(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HelloListener ) ((HelloListener)listener).exitBlockNode(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HelloVisitor ) return ((HelloVisitor<? extends T>)visitor).visitBlockNode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final BlockNodeContext blockNode() throws RecognitionException {
		BlockNodeContext _localctx = new BlockNodeContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_blockNode);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(100);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,6,_ctx) ) {
			case 1:
				{
				setState(96);
				assignment();
				}
				break;
			case 2:
				{
				setState(97);
				whileNode();
				}
				break;
			case 3:
				{
				setState(98);
				ifNode();
				}
				break;
			case 4:
				{
				setState(99);
				sequenceNode();
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class SequenceNodeContext extends ParserRuleContext {
		public List<AssignmentContext> assignment() {
			return getRuleContexts(AssignmentContext.class);
		}
		public AssignmentContext assignment(int i) {
			return getRuleContext(AssignmentContext.class,i);
		}
		public List<IfNodeContext> ifNode() {
			return getRuleContexts(IfNodeContext.class);
		}
		public IfNodeContext ifNode(int i) {
			return getRuleContext(IfNodeContext.class,i);
		}
		public List<WhileNodeContext> whileNode() {
			return getRuleContexts(WhileNodeContext.class);
		}
		public WhileNodeContext whileNode(int i) {
			return getRuleContext(WhileNodeContext.class,i);
		}
		public SequenceNodeContext sequenceNode() {
			return getRuleContext(SequenceNodeContext.class,0);
		}
		public SequenceNodeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_sequenceNode; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof HelloListener ) ((HelloListener)listener).enterSequenceNode(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof HelloListener ) ((HelloListener)listener).exitSequenceNode(this);
		}
		@Override
		public <T> T accept(ParseTreeVisitor<? extends T> visitor) {
			if ( visitor instanceof HelloVisitor ) return ((HelloVisitor<? extends T>)visitor).visitSequenceNode(this);
			else return visitor.visitChildren(this);
		}
	}

	public final SequenceNodeContext sequenceNode() throws RecognitionException {
		SequenceNodeContext _localctx = new SequenceNodeContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_sequenceNode);
		try {
			setState(119);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,10,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(105);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case VAR:
					{
					setState(102);
					assignment();
					}
					break;
				case T__1:
					{
					setState(103);
					ifNode();
					}
					break;
				case T__5:
					{
					setState(104);
					whileNode();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(110);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case VAR:
					{
					setState(107);
					assignment();
					}
					break;
				case T__1:
					{
					setState(108);
					ifNode();
					}
					break;
				case T__5:
					{
					setState(109);
					whileNode();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(115);
				_errHandler.sync(this);
				switch (_input.LA(1)) {
				case VAR:
					{
					setState(112);
					assignment();
					}
					break;
				case T__1:
					{
					setState(113);
					ifNode();
					}
					break;
				case T__5:
					{
					setState(114);
					whileNode();
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(117);
				sequenceNode();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public boolean sempred(RuleContext _localctx, int ruleIndex, int predIndex) {
		switch (ruleIndex) {
		case 5:
			return aexpr_sempred((AexprContext)_localctx, predIndex);
		case 6:
			return bexpr_sempred((BexprContext)_localctx, predIndex);
		}
		return true;
	}
	private boolean aexpr_sempred(AexprContext _localctx, int predIndex) {
		switch (predIndex) {
		case 0:
			return precpred(_ctx, 3);
		case 1:
			return precpred(_ctx, 2);
		}
		return true;
	}
	private boolean bexpr_sempred(BexprContext _localctx, int predIndex) {
		switch (predIndex) {
		case 2:
			return precpred(_ctx, 3);
		}
		return true;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\26|\4\2\t\2\4\3\t"+
		"\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\3\2\3\2\3\2"+
		"\3\3\3\3\3\3\3\3\3\3\3\4\3\4\3\4\3\4\7\4!\n\4\f\4\16\4$\13\4\3\4\3\4\3"+
		"\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3\6\3\6\3\6\3\6\3\6\3\6\3\7\3\7"+
		"\3\7\3\7\3\7\3\7\3\7\5\7?\n\7\3\7\3\7\3\7\3\7\3\7\3\7\7\7G\n\7\f\7\16"+
		"\7J\13\7\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\3\b\5\bY\n\b"+
		"\3\b\3\b\3\b\7\b^\n\b\f\b\16\ba\13\b\3\t\3\t\3\t\3\t\5\tg\n\t\3\n\3\n"+
		"\3\n\5\nl\n\n\3\n\3\n\3\n\5\nq\n\n\3\n\3\n\3\n\5\nv\n\n\3\n\3\n\5\nz\n"+
		"\n\3\n\2\4\f\16\13\2\4\6\b\n\f\16\20\22\2\2\2\u0087\2\24\3\2\2\2\4\27"+
		"\3\2\2\2\6\34\3\2\2\2\b\'\3\2\2\2\n\61\3\2\2\2\f>\3\2\2\2\16X\3\2\2\2"+
		"\20f\3\2\2\2\22y\3\2\2\2\24\25\5\6\4\2\25\26\5\22\n\2\26\3\3\2\2\2\27"+
		"\30\7\16\2\2\30\31\7\24\2\2\31\32\5\f\7\2\32\33\7\26\2\2\33\5\3\2\2\2"+
		"\34\35\7\3\2\2\35\"\7\16\2\2\36\37\7\25\2\2\37!\7\16\2\2 \36\3\2\2\2!"+
		"$\3\2\2\2\" \3\2\2\2\"#\3\2\2\2#%\3\2\2\2$\"\3\2\2\2%&\7\26\2\2&\7\3\2"+
		"\2\2\'(\7\4\2\2()\5\16\b\2)*\7\5\2\2*+\5\20\t\2+,\7\6\2\2,-\7\7\2\2-."+
		"\7\5\2\2./\5\20\t\2/\60\7\6\2\2\60\t\3\2\2\2\61\62\7\b\2\2\62\63\5\16"+
		"\b\2\63\64\7\5\2\2\64\65\5\20\t\2\65\66\7\6\2\2\66\13\3\2\2\2\678\b\7"+
		"\1\28?\7\16\2\29?\7\f\2\2:;\7\t\2\2;<\5\f\7\2<=\7\n\2\2=?\3\2\2\2>\67"+
		"\3\2\2\2>9\3\2\2\2>:\3\2\2\2?H\3\2\2\2@A\f\5\2\2AB\7\20\2\2BG\5\f\7\5"+
		"CD\f\4\2\2DE\7\17\2\2EG\5\f\7\5F@\3\2\2\2FC\3\2\2\2GJ\3\2\2\2HF\3\2\2"+
		"\2HI\3\2\2\2I\r\3\2\2\2JH\3\2\2\2KL\b\b\1\2LY\7\16\2\2MY\7\r\2\2NO\7\22"+
		"\2\2OY\5\16\b\6PQ\5\f\7\2QR\7\23\2\2RS\5\f\7\2SY\3\2\2\2TU\7\t\2\2UV\5"+
		"\16\b\2VW\7\n\2\2WY\3\2\2\2XK\3\2\2\2XM\3\2\2\2XN\3\2\2\2XP\3\2\2\2XT"+
		"\3\2\2\2Y_\3\2\2\2Z[\f\5\2\2[\\\7\21\2\2\\^\5\16\b\6]Z\3\2\2\2^a\3\2\2"+
		"\2_]\3\2\2\2_`\3\2\2\2`\17\3\2\2\2a_\3\2\2\2bg\5\4\3\2cg\5\n\6\2dg\5\b"+
		"\5\2eg\5\22\n\2fb\3\2\2\2fc\3\2\2\2fd\3\2\2\2fe\3\2\2\2fg\3\2\2\2g\21"+
		"\3\2\2\2hl\5\4\3\2il\5\b\5\2jl\5\n\6\2kh\3\2\2\2ki\3\2\2\2kj\3\2\2\2l"+
		"p\3\2\2\2mq\5\4\3\2nq\5\b\5\2oq\5\n\6\2pm\3\2\2\2pn\3\2\2\2po\3\2\2\2"+
		"qz\3\2\2\2rv\5\4\3\2sv\5\b\5\2tv\5\n\6\2ur\3\2\2\2us\3\2\2\2ut\3\2\2\2"+
		"vw\3\2\2\2wx\5\22\n\2xz\3\2\2\2yk\3\2\2\2yu\3\2\2\2z\23\3\2\2\2\r\">F"+
		"HX_fkpuy";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}
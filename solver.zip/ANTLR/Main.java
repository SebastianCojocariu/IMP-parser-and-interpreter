import org.antlr.v4.runtime.CharStream;
import org.antlr.v4.runtime.CharStreams;
import org.antlr.v4.runtime.CommonTokenStream;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
public class Main{
	public static void main(String[] args) throws IOException{

		BufferedWriter output_tree = new BufferedWriter(new FileWriter(new File("arbore")));
		MyListener.writer = output_tree;

		CharStream charstream = CharStreams.fromFileName("input");
		HelloLexer lexer = new HelloLexer(charstream);
		CommonTokenStream commonTokenStream = new CommonTokenStream(lexer);
		HelloParser parser = new HelloParser(commonTokenStream);

		ParseTreeWalker walker = new ParseTreeWalker();
		HelloListener listener = new MyListener();
		walker.walk(listener,parser.mainNode());
		
		output_tree.close();
	}
}
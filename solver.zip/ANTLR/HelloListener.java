// Generated from Hello.g4 by ANTLR 4.7.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link HelloParser}.
 */
public interface HelloListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link HelloParser#mainNode}.
	 * @param ctx the parse tree
	 */
	void enterMainNode(HelloParser.MainNodeContext ctx);
	/**
	 * Exit a parse tree produced by {@link HelloParser#mainNode}.
	 * @param ctx the parse tree
	 */
	void exitMainNode(HelloParser.MainNodeContext ctx);
	/**
	 * Enter a parse tree produced by {@link HelloParser#assignment}.
	 * @param ctx the parse tree
	 */
	void enterAssignment(HelloParser.AssignmentContext ctx);
	/**
	 * Exit a parse tree produced by {@link HelloParser#assignment}.
	 * @param ctx the parse tree
	 */
	void exitAssignment(HelloParser.AssignmentContext ctx);
	/**
	 * Enter a parse tree produced by {@link HelloParser#initialize}.
	 * @param ctx the parse tree
	 */
	void enterInitialize(HelloParser.InitializeContext ctx);
	/**
	 * Exit a parse tree produced by {@link HelloParser#initialize}.
	 * @param ctx the parse tree
	 */
	void exitInitialize(HelloParser.InitializeContext ctx);
	/**
	 * Enter a parse tree produced by {@link HelloParser#ifNode}.
	 * @param ctx the parse tree
	 */
	void enterIfNode(HelloParser.IfNodeContext ctx);
	/**
	 * Exit a parse tree produced by {@link HelloParser#ifNode}.
	 * @param ctx the parse tree
	 */
	void exitIfNode(HelloParser.IfNodeContext ctx);
	/**
	 * Enter a parse tree produced by {@link HelloParser#whileNode}.
	 * @param ctx the parse tree
	 */
	void enterWhileNode(HelloParser.WhileNodeContext ctx);
	/**
	 * Exit a parse tree produced by {@link HelloParser#whileNode}.
	 * @param ctx the parse tree
	 */
	void exitWhileNode(HelloParser.WhileNodeContext ctx);
	/**
	 * Enter a parse tree produced by {@link HelloParser#aexpr}.
	 * @param ctx the parse tree
	 */
	void enterAexpr(HelloParser.AexprContext ctx);
	/**
	 * Exit a parse tree produced by {@link HelloParser#aexpr}.
	 * @param ctx the parse tree
	 */
	void exitAexpr(HelloParser.AexprContext ctx);
	/**
	 * Enter a parse tree produced by {@link HelloParser#bexpr}.
	 * @param ctx the parse tree
	 */
	void enterBexpr(HelloParser.BexprContext ctx);
	/**
	 * Exit a parse tree produced by {@link HelloParser#bexpr}.
	 * @param ctx the parse tree
	 */
	void exitBexpr(HelloParser.BexprContext ctx);
	/**
	 * Enter a parse tree produced by {@link HelloParser#blockNode}.
	 * @param ctx the parse tree
	 */
	void enterBlockNode(HelloParser.BlockNodeContext ctx);
	/**
	 * Exit a parse tree produced by {@link HelloParser#blockNode}.
	 * @param ctx the parse tree
	 */
	void exitBlockNode(HelloParser.BlockNodeContext ctx);
	/**
	 * Enter a parse tree produced by {@link HelloParser#sequenceNode}.
	 * @param ctx the parse tree
	 */
	void enterSequenceNode(HelloParser.SequenceNodeContext ctx);
	/**
	 * Exit a parse tree produced by {@link HelloParser#sequenceNode}.
	 * @param ctx the parse tree
	 */
	void exitSequenceNode(HelloParser.SequenceNodeContext ctx);
}
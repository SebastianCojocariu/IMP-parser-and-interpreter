import org.antlr.v4.runtime.ParserRuleContext;
import org.antlr.v4.runtime.tree.ErrorNode;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.tree.ParseTreeWalker;
import org.antlr.v4.runtime.tree.TerminalNode;

import java.io.BufferedWriter;
import java.io.IOException;

public class MyListener implements HelloListener {

    public static BufferedWriter writer;

    static int no_tabs = 0;
    static boolean ok_aexpr = false;
    static boolean ok = false;

    public String getTabs(){
        String res = "";
        for(int i=0;i<no_tabs;i++)
            res = res + "\t";
        return res;
    }
    @Override public void enterMainNode(HelloParser.MainNodeContext ctx) {
        try {
            writer.write(getTabs() + "<MainNode>\n");
            no_tabs++;
        }catch(Exception e){

        }
    }

    @Override public void exitMainNode(HelloParser.MainNodeContext ctx) {
        no_tabs--;
    }

    @Override public void enterAssignment(HelloParser.AssignmentContext ctx) {
        try {
            writer.write(getTabs() + "<AssignmentNode> =\n");
            no_tabs++;
        }catch(Exception e){

        }
    }

    @Override public void exitAssignment(HelloParser.AssignmentContext ctx) {
        no_tabs--;
    }

    @Override public void enterIfNode(HelloParser.IfNodeContext ctx) {
        try {
            writer.write(getTabs() + "<IfNode> if\n");
            no_tabs++;
        }catch(Exception e){

        }
    }
    @Override public void exitIfNode(HelloParser.IfNodeContext ctx) { no_tabs-- ; }

    @Override public void enterWhileNode(HelloParser.WhileNodeContext ctx) {
        try {
            writer.write(getTabs() + "<WhileNode> while\n");
            no_tabs++;
        }catch(Exception e){

        }
    }
    @Override public void exitWhileNode(HelloParser.WhileNodeContext ctx) { no_tabs--; }

    @Override public void enterAexpr(HelloParser.AexprContext ctx) {

        //Plus
        if(ctx.getChildCount() == 3 && ctx.getChild(0).getText().equals("(")) {
            try {
                writer.write(getTabs() + "<BracketNode> ()\n");
                no_tabs++;
            }catch(Exception e){

            }
        }
        else if(ctx.getChildCount() == 3 && ctx.getChild(1).getText().equals("+")) {
            try {
                writer.write(getTabs() + "<PlusNode> +\n");
                no_tabs++;
            }catch(Exception e){

            }
        }
        //Div
        else if(ctx.getChildCount() == 3 && ctx.getChild(1).getText().equals("/")) {
            try {
                writer.write(getTabs() + "<DivNode> /\n");
                no_tabs++;
            }catch(Exception e){

            }
        }
        //terminal
        else if(ctx.getChildCount() == 1){

        }


    }
    @Override public void exitAexpr(HelloParser.AexprContext ctx) {
        if(ctx.getChildCount() != 1)
            no_tabs--;
    }

    @Override public void enterBexpr(HelloParser.BexprContext ctx) {


        if(ctx.getChildCount() == 3 && ctx.getChild(0).getText().equals("(")) {
            try {
                writer.write(getTabs() + "<BracketNode> ()\n");
                no_tabs++;
            }catch(Exception e){

            }
        }
        //And
        else if(ctx.getChildCount() == 3 && ctx.getChild(1).getText().equals("&&")) {
            try {
                writer.write(getTabs() + "<AndNode> &&\n");
                no_tabs++;
            }catch(Exception e){

            }
        }
        //Greater
        else if(ctx.getChildCount() == 3 && ctx.getChild(1).getText().equals(">")) {
            try {
                writer.write(getTabs() + "<GreaterNode> >\n");
                no_tabs++;
            }catch(Exception e){

            }
        }
        //Not
        else if(ctx.getChildCount() == 2 && ctx.getChild(0).getText().equals("!")) {
            try {
                writer.write(getTabs() + "<NotNode> !\n");
                no_tabs++;
            }catch(Exception e){

            }

        }
        else if(ctx.getChildCount() == 1){

        }
    }

    @Override public void exitBexpr(HelloParser.BexprContext ctx) {
        if(ctx.getChildCount() != 1)
            no_tabs--;
    }

    @Override public void enterBlockNode(HelloParser.BlockNodeContext ctx) {
        try {
            writer.write(getTabs() + "<BlockNode> {}\n");
            no_tabs++;
        }catch(Exception e){

        }
    }

    @Override public void exitBlockNode(HelloParser.BlockNodeContext ctx) {no_tabs--; }

    @Override public void enterSequenceNode(HelloParser.SequenceNodeContext ctx) {
        try {
            writer.write(getTabs() + "<SequenceNode>\n");
            no_tabs++;
        }catch(Exception e){

        }
    }

    @Override public void exitSequenceNode(HelloParser.SequenceNodeContext ctx) { no_tabs--; }


    @Override public void visitTerminal(TerminalNode node) {
        if(!ok)
            return;

        String text = node.toString();
        if(text.equals("while") || text.equals("if") || text.equals("else") || text.equals(";") || text.equals("=") ||
                text.equals("!") || text.equals("+") || text.equals("/"))
            return;

        //boolean
        else if(text.equals("true") || text.equals("false") || text.equals("True") || text.equals("False")) {
            try {
                writer.write(getTabs() + "<BoolNode> "+ text + "\n");
            } catch (Exception e) {

            }
        }

        //variabila
        else if(text.charAt(0) >= 'A' && text.charAt(0) <= 'z') {
            try {
                writer.write(getTabs() + "<VariableNode> "+ text + "\n");
            } catch (Exception e) {

            }
        }

        //numar
        else if(text.charAt(0) >='0' && text.charAt(0) <= '9') {
            try {
                writer.write(getTabs() + "<IntNode> "+ text + "\n");
            } catch (Exception e) {

            }
        }

    }

    @Override public void enterInitialize(HelloParser.InitializeContext ctx) { }

    @Override public void exitInitialize(HelloParser.InitializeContext ctx) {ok = true; }

    @Override public void visitErrorNode(ErrorNode node) { }

    @Override public void enterEveryRule(ParserRuleContext ctx) { }

    @Override public void exitEveryRule(ParserRuleContext ctx) { }
}

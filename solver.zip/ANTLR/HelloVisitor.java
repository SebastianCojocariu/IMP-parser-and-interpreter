// Generated from Hello.g4 by ANTLR 4.7.1
import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link HelloParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface HelloVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link HelloParser#mainNode}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMainNode(HelloParser.MainNodeContext ctx);
	/**
	 * Visit a parse tree produced by {@link HelloParser#assignment}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignment(HelloParser.AssignmentContext ctx);
	/**
	 * Visit a parse tree produced by {@link HelloParser#initialize}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitInitialize(HelloParser.InitializeContext ctx);
	/**
	 * Visit a parse tree produced by {@link HelloParser#ifNode}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfNode(HelloParser.IfNodeContext ctx);
	/**
	 * Visit a parse tree produced by {@link HelloParser#whileNode}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhileNode(HelloParser.WhileNodeContext ctx);
	/**
	 * Visit a parse tree produced by {@link HelloParser#aexpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAexpr(HelloParser.AexprContext ctx);
	/**
	 * Visit a parse tree produced by {@link HelloParser#bexpr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBexpr(HelloParser.BexprContext ctx);
	/**
	 * Visit a parse tree produced by {@link HelloParser#blockNode}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBlockNode(HelloParser.BlockNodeContext ctx);
	/**
	 * Visit a parse tree produced by {@link HelloParser#sequenceNode}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitSequenceNode(HelloParser.SequenceNodeContext ctx);
}
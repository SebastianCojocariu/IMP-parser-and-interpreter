java -jar antlr-4.7.1-complete.jar -visitor Hello.g4 
javac -cp ./antlr-4.7.1-complete.jar *.java
java -cp .:antlr-4.7.1-complete.jar org.antlr.v4.gui.TestRig Hello mainNode -gui input.txt 